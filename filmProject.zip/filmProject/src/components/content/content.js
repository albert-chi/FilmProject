import react from 'react';
import './content.css';

const Content = () => {
    return (
        <>
        
            
       </>
    );
}

export default Content;