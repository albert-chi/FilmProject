export const BASE_URL  = 'https://api.themoviedb.org/3';
export const Path_Discover = '/discover/movie';
export const apikey = "89f2019f38dcdeac674ecf0b7266de73";